__all__ = ['fwer', 'fdr', 'data', 'permutation', 'rft', 'util', 'viz']
